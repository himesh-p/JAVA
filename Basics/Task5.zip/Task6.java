//6. Create a simple password validation system that prompts the user to enter a password and checks if it meets certain criteria (e.g., minimum length, containing numbers and special characters).

import java.util.Scanner;
public class Task6{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the any Passward but criteria(minimum length, containing numbers and special characters) :- ");
		String pass = sc.nextLine();
		//int len = pass.length();
		//if(pass >= len || pass){}
		
		System.out.println();
	}
}